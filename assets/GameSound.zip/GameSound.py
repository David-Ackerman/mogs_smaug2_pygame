import os
import pygame
pygame.init()
pygame.mixer.init()
pygame.mixer.music.load("dramatic.wav")
pygame.mixer.music.play()